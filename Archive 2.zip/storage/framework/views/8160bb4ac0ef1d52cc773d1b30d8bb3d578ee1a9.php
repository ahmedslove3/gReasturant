  <!DOCTYPE html>
  <html lang="en" dir="ltr">
    <head>
      <meta charset="utf-8">
      <title></title>
    </head>
    <body>
      <h1><?php echo $name ?></h1> // user can change and trigger alert for example
       // <?php echo e($name); ?> this way user can't 
    </body>
  </html>
<?php /**PATH C:\Users\Elradwa\project\resources\views/test.blade.php ENDPATH**/ ?>