  <!DOCTYPE html>
  <html lang="en" dir="ltr">
    <head>
      <meta charset="utf-8">
      <title></title>
    </head>
    <body>
      <h1><? $name; ?></h1>
    </body>
  </html>
<?php /**PATH C:\Users\Elradwa\project\resources\views//test.blade.php ENDPATH**/ ?>