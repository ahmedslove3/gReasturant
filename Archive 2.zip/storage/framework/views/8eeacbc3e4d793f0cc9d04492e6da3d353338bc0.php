<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>My Blog Post</h1>

    <p><?php echo e($post); ?></p> //  post->body

  </body>
</html>
<?php /**PATH C:\Users\Elradwa\project\resources\views/post.blade.php ENDPATH**/ ?>