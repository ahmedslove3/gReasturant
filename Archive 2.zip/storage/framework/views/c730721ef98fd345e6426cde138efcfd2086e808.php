<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1> <?php echo e($name); ?></h1>
  </body>
</html>
<?php /**PATH C:\Users\Elradwa\project\resources\views//mo.blade.php ENDPATH**/ ?>