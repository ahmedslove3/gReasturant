<?php

namespace App\Voyager;

use TCG\Voyager\Http\Controllers\VoyagerUserController as BaseVoyagerUserController;

class UserController extends BaseVoyagerUserController
{
    //
}
